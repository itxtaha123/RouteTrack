# RouteTrack Online

Upload `index.html`, `manifest.json`, and `sw.js` to any static website host. Then open the resulting HTTPS link on Android Chrome and allow location access.

The app stores trips in the phone browser. It uses OpenStreetMap tiles and OSRM for planned routes.
